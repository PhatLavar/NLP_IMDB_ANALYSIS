# Draft sections: Results and Error Analysis

Draft for the team report (Kiet, 17/11). Every number below is recomputed from `results/predictions/preds_*.csv` and the annotation files by `eval/error_analysis.py`, and re-derived independently by `eval/verify_draft.py`. Each statement names the table it comes from (paths under `results/eval/`).

## Results

All five models were evaluated on the same 25,000 test reviews (positive class = 1). Table 1 (`metrics_table.csv`):

| Model | Accuracy | Precision | Recall | F1 | ROC-AUC | FP | FN |
|---|---:|---:|---:|---:|---:|---:|---:|
| TF-IDF + LogReg | 0.8804 | 0.8767 | 0.8853 | 0.8809 | 0.9513 | 1,557 | 1,434 |
| TF-IDF + LinearSVC | 0.8868 | 0.8894 | 0.8836 | 0.8865 | 0.9551 | 1,374 | 1,455 |
| Word2Vec + LogReg | 0.8563 | 0.8607 | 0.8502 | 0.8554 | 0.9328 | 1,720 | 1,873 |
| Word2Vec + LinearSVC | 0.8572 | 0.8621 | 0.8505 | 0.8562 | 0.9335 | 1,701 | 1,869 |
| DistilBERT + LoRA | 0.9256 | 0.9132 | 0.9407 | 0.9267 | 0.9773 | 1,118 | 741 |

- **DistilBERT + LoRA is best on every metric.** Its accuracy is 0.0388 higher than the best classical model, TF-IDF + LinearSVC, and it makes 970 fewer errors (1,859 vs 2,829) (`metrics_table.csv`).
- **In our setup (averaged Word2Vec vectors, classifiers at the default C), the representation matters more than the classifier.** TF-IDF beats Word2Vec with both classifiers. Switching LogReg to LinearSVC changes accuracy by only 0.0065 (TF-IDF) and 0.0009 (Word2Vec) (`metrics_table.csv`).
- **Error direction.** DistilBERT + LoRA has more false positives than false negatives (1,118 vs 741), so its recall (0.9407) is higher than its precision (0.9132). The classical models are closer to balanced (`metrics_table.csv`; figure `figures/confusion_matrices.png`).
- **ROC-AUC** uses only the ranking of the scores, so it is valid for the LinearSVC models too. We do not report log loss, Brier score or calibration, because the LinearSVC "probability" is expit(decision_function), an uncalibrated score.
- **Consistency check.** Accuracy, precision, recall and F1 recomputed from the prediction files equal the numbers in `results/ml_results.csv` and `results/dl_results.csv` for all five models; the largest absolute difference is 0.000000 (`error_analysis/preflight_metric_crosscheck.csv`).
- **Shared errors.** 708 test reviews are misclassified by all five models (702 after removing duplicated texts, the population used for sampling) (`cross_model_summary.md`, `error_analysis/sample_design.csv`).

## Error Analysis

### Sample and method

We labelled 100 reviews that DistilBERT + LoRA misclassified, drawn by `eval/tag_errors.py` (seed 42) from the DL errors with duplicated texts removed (1,840 of 1,859 errors). The sample is stratified (`error_analysis/sample_design.csv`):

- 40 of the 702 reviews misclassified by all five models (group `all5`);
- 60 of the 1,138 reviews misclassified by DistilBERT but not by all five models (group `other`).

The two sampling fractions are close (0.0570 and 0.0527), so the unweighted shares below are close to the stratified estimates for all DL errors in `error_analysis/category_weighted.csv`. With n = 100 those estimates are rough: for example, `mixed` as main category is 47 of 100 in the sample, and the weighted estimate is 0.4714 with a 95% interval of 0.3755 to 0.5673. **The counts describe DistilBERT errors only; they are not error rates of the classical models.**

Each review got one or more categories (`sarcasm`, `negation`, `mixed`, `long_truncated`, `label_noise`, `other`; main reason first). One annotator labelled both halves (files A and B), with AI-suggested categories on screen (see "AI assistance" below).

### Categories (sample counts)

From `error_analysis/category_counts.csv` (figure `figures/error_categories.png`):

| Category | Main category | Any value |
|---|---:|---:|
| mixed | 47 | 72 |
| other | 21 | 28 |
| label_noise | 17 | 20 |
| sarcasm | 9 | 18 |
| negation | 5 | 24 |
| long_truncated | 1 | 2 |

- **Mixed opinions dominate.** `mixed` is the main reason for 47 of 100 errors and appears in 72. Reviews often praise parts and criticise others. 62 of 100 reviews have two or more categories (`error_analysis/multilabel_summary.csv`).
- **Negation is common as a secondary reason (24) but rarely the main one (5).**
- **Label noise is more frequent in errors all models share.** `label_noise` is the main category for 10 of 40 `all5` reviews but 7 of 60 `other` reviews. Sarcasm goes the other way: main category for 1 of 40 `all5` reviews but 8 of 60 `other` reviews. These subgroup counts are small.
- **Annotation halves.** The two annotation halves differ in how often `mixed` is the main category (28 vs 19 of 50). Both halves were labelled by the same person, so we do not attribute this to annotator differences (`error_analysis/category_counts.csv`).
- **Per model.** Only 33% of TF-IDF + LogReg's test errors (34% for TF-IDF + LinearSVC, 28% for Word2Vec + LogReg and 28% for Word2Vec + LinearSVC) are also DistilBERT errors, so the hand labels describe only that overlapping part of their errors (`error_analysis/per_model_categories.csv`).

### Truncation

DistilBERT reads at most 510 wordpieces: the first 128 and the last 382 (`results/dl_config.csv`, `dl/train_lora.py` `build_inputs`). 17 of the 100 sampled reviews are longer than that (`error_analysis/dl_wordpieces.csv`), but only 2 were labelled `long_truncated`:

- test_14218 (positive): the strongest praise, "Undoubtedly it has been a major success", is in the unseen middle, and the visible end is mostly criticism.
- test_22750 (positive): "I liked Brain of Blood a lot" is in the unseen middle, but the visible end also says "I liked it". The truncation removed the clearest praise, not the only praise.

So truncation explains at most 2 of 100 sampled errors, and clearly only one (`error_analysis/long_truncated_cases.csv`; this split is our reading of the two texts).

### Label noise

20 of 100 reviews have `label_noise` (17 as main category; `error_analysis/label_noise_cases.csv`). The dataset has no rating column, so the rating cannot be checked directly. In test_06593 (labelled negative) the review's author writes "8/10" at the end.

### Do the automatic heuristics match the hand labels?

`eval/tag_errors.py` tags reviews with keyword heuristics. On the 100 labelled errors (`error_analysis/heuristic_vs_hand.csv`, gold = hand label, any value):

- **No heuristic is reliable enough to report as a category rate.** The best agreement is `has_contrast_cue` vs `mixed` with Cohen's kappa 0.3353, which is only "fair".
- `neg_cue_strict` fires on 93 of 100 reviews; its precision for `negation` is 0.2581, barely above the 0.2400 base rate.
- `negated_sentiment_any` finds 0.3333 of the `negation` reviews, with precision 0.4211.
- `mixed_candidate` has precision 0.8750 for `mixed`, but 0.7200 of all labelled errors are `mixed` anyway.
- `truncated` finds both `long_truncated` reviews (recall 1.0000) with precision 0.1176. It is a length fact, not a cause, and it was not blind: the labelling tool greyed out the unseen middle.

We therefore report `truncated` only as a length descriptor and do not report the heuristic error-rate tables (`error_rate_by_category.csv`) as evidence about negation or mixed opinions.

### AI assistance

AI-suggested categories (`results/eval/suggestions/llm_suggestions.csv`) were shown for 97 reviews; 3 reviews were labelled before the suggestions existed (`error_analysis/ai_decisions.csv`). 1 of those 3 (test_04366) was revised after its suggestion was seen: its category changed from `mixed` to `label_noise;mixed`, which is the suggested main and secondary category. The revision was saved with the labelling tool's save function but outside its interface, so it has no row in the decision log (`error_analysis/ai_vs_final.csv`, column `revised_after_ai`). Of the 97, 69 suggestions were accepted unchanged and 28 were edited; 18 of the 28 edits only removed the "unsure" flag. For 2 of the 3 reviews labelled before the suggestions existed, the final label differs from the suggestion (for test_04366 only in the "unsure" flag), so `error_analysis/ai_edited_cases.csv` lists 30 reviews.

**AI suggestion vs final label (not inter-annotator agreement):** the main category is the same for 97 of 100 reviews (raw agreement 0.9700, Cohen's kappa 0.9566), and for 96 of the 98 reviews whose final label was set with the suggestion seen (kappa 0.9706) (`error_analysis/ai_agreement.csv`). The AI suggested `mixed` as main category 48 times; the final main category differs in 2 of them. It suggested `label_noise` 16 times, and the final main category is `label_noise` in 16 of them (`error_analysis/ai_edit_rate_by_category.csv`). The final labels are therefore very close to the AI suggestions, and the category distribution may reflect the AI's tendencies, for example its frequent `mixed`.

### Examples (short excerpts)

| Category | Review | True label | Excerpt |
|---|---|---|---|
| sarcasm | test_01183 | negative | "That ballot box was stuffed better than a Christmas turkey!" |
| sarcasm | test_02554 | negative | "hilarious antics ensue (I wish)" |
| negation | test_14247 | positive | "it's not too bad" |
| negation | test_00383 | negative | "It's not half as good any of those films." |
| mixed | test_13076 | positive | "It is really stupid and lame for the first half, then it actually starts to get good for the last half." |
| mixed | test_02576 | negative | "Most of this film was okay" ... "you should go watch something else." |
| long_truncated | test_14218 | positive | "Undoubtedly it has been a major success" (unseen middle) |
| long_truncated | test_22750 | positive | "I liked Brain of Blood a lot" (unseen middle) |
| label_noise | test_04811 | negative | "an innovative comedy that is genuinely funny and really touching at many times" |
| label_noise | test_12989 | positive | "one-liners so flat and unfunny" |
| label_noise | test_06593 | negative | "one of the strongest Russian movie for the past few years" ... "8/10" |
| other | test_16793 | positive | "an insufferable jerk who I was praying would meet an extremely brutal and prolonged demise" (about a character, not the film) |
| other | test_24629 | positive | "PLEASE PICK UP THE SHOW!!!!" (praise through anger at the cancellation) |

### Limitations

1. **Unequal tuning.** The classical models were barely tuned: TF-IDF uses ngram_range (1, 2), min_df 2, max_df 0.95 and sublinear_tf; LogReg and LinearSVC keep the default C = 1.0; Word2Vec uses 100 dimensions, window 5, min_count 2, skip-gram and 10 epochs (`ml/model.py`, `results/ml_config.csv`). The repository has no tuning log for the classical models. DistilBERT + LoRA was tuned over 8 configurations on the validation set (`results/dl_tuning.csv`).
2. **Possible optimism of the classical scores.** According to the ML teammate, the TF-IDF configuration was chosen after looking at both validation and test metrics, so the classical test scores may be slightly optimistic. DistilBERT's configuration and best epoch (8) were selected on validation only, and the test set was evaluated once (`dl/train_lora.py`, `results/dl_config.csv`).
3. **SVM scores are not probabilities.** The LinearSVC `prob` column is expit(decision_function), so no calibration metric is reported for those models.
4. **Label noise.** IMDB labels come from the authors' own 1-10 ratings (4 or lower = negative, 7 or higher = positive, 5-6 excluded; Maas et al., 2011), so a review's text can disagree with its label; 20 of 100 sampled errors were labelled `label_noise`.
5. **Truncation.** DistilBERT reads at most 510 wordpieces (head 128 + tail 382); 17 of 100 sampled errors are longer.
6. **One annotator with AI suggestions.** All 100 reviews were labelled by one person with AI-suggested categories on screen, so there is no inter-annotator agreement. The final main category equals the AI suggestion for 97 of 100 reviews. 9 reviews were marked unsure and were not discussed.
7. **Sampling design.** The sample contains only DistilBERT errors, drawn in two strata; category counts are sample counts, and shares generalise only to DistilBERT errors, with wide intervals at n = 100.
