Package for Person 1: Results and Error Analysis sections (IMDB sentiment), from Kiet.

THE DRAFT
  results_error_analysis_draft.md   the Results and Error Analysis sections. Every number in it was
                                    re-derived by scripts/verify_draft.py, and all checks passed.

WHERE THE NUMBERS COME FROM (paths in the draft resolve from this folder)
  results/eval/metrics_table.csv, .md   Table 1 (accuracy, precision, recall, F1, ROC-AUC, FP, FN),
                                        recomputed from the prediction files
  results/eval/error_analysis/          every error-analysis table; tables.md holds all of them in one file
      sample_design.csv                 sampling strata and fractions
      category_counts.csv               category counts in the 100-review sample (sample counts, also per half A/B)
      category_weighted.csv             weighted estimates for all DistilBERT errors, with 95% intervals
      multilabel_summary.csv            reviews with several categories
      per_model_categories.csv          overlap of each classical model's errors with DistilBERT errors
      dl_wordpieces.csv, long_truncated_cases.csv   truncation (DistilBERT head + tail)
      label_noise_cases.csv             reviews labelled label_noise
      heuristic_vs_hand.csv             keyword heuristics vs hand labels
      ai_*.csv                          AI suggestion vs final label (NOT inter-annotator agreement)
      preflight_*.csv                   input checks (metrics vs teammates' files, annotation completeness)
  results/eval/figures/                 the two figures
  results/eval/annotation/annotations_final.csv   merged hand labels (output of eval/merge_annotations.py)
  results/eval/suggestions/             AI-suggested categories and the labelling tool's decision log
  results/eval/cross_model_summary.md   reviews misclassified by all five models
  results/ml_*.csv, results/dl_*.csv    copies of teammates' result and config files cited in the draft
  scripts/                              copies of eval/error_analysis.py, eval/make_figures.py, eval/verify_draft.py

NOT INCLUDED: the prediction files results/predictions/preds_*.csv (large; cited as the source), the two
annotator files, ml/, dl/, demo/ and the models.

HOW TO REPRODUCE (from the repository root, with the existing environment, no installs)
  python eval/merge_annotations.py
  python eval/error_analysis.py
  python eval/make_figures.py
  python eval/verify_draft.py        prints "X of Y checks passed"
The scripts need the full repository (prediction files, annotator files, tokenizer in models/hf_cache);
they do not run from this package alone.

NOTE: test_04366 was first labelled before the AI suggestions existed and was revised (mixed ->
label_noise;mixed) after its suggestion was seen. See the AI assistance section of the draft.

CAVEATS (details and numbers in the draft's Limitations section)
  - Unequal tuning: the classical models were barely tuned; DistilBERT + LoRA was tuned on validation.
  - Classical test scores may be slightly optimistic (per the ML teammate; not verifiable from the repository).
  - LinearSVC scores are not probabilities, so no calibration metric is reported.
  - Some IMDB labels disagree with the review text (label noise).
  - DistilBERT reads only the head and tail of long reviews (truncation).
  - One annotator with AI suggestions on screen: no inter-annotator agreement; final labels are very close
    to the AI suggestions.
  - The sample contains only DistilBERT errors; shares generalise only to DistilBERT errors, with wide intervals.
